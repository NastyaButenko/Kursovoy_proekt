-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3307
-- Время создания: Дек 05 2020 г., 11:46
-- Версия сервера: 10.3.13-MariaDB-log
-- Версия PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `agent_arm`
--
CREATE DATABASE IF NOT EXISTS `agent_arm` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `agent_arm`;

-- --------------------------------------------------------

--
-- Структура таблицы `agent`
--

CREATE TABLE `agent` (
  `idagent` int(11) NOT NULL,
  `FIO_agent` varchar(50) NOT NULL,
  `agent_login` varchar(15) NOT NULL,
  `agent_parol` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `agent`
--

INSERT INTO `agent` (`idagent`, `FIO_agent`, `agent_login`, `agent_parol`) VALUES
(1, 'Лушина Алеся Эдуардовна', 'Lushina_ae', 'alesya12345'),
(2, 'test', 'test', '123456789');

-- --------------------------------------------------------

--
-- Структура таблицы `edinovr_oplata`
--

CREATE TABLE `edinovr_oplata` (
  `edinovr_oplata` int(11) NOT NULL,
  `idagent` int(11) NOT NULL DEFAULT 1,
  `index_str` varchar(15) NOT NULL,
  `idstrahovatel` int(11) NOT NULL,
  `nomer_dogovora` varchar(45) NOT NULL,
  `data_nachala` date NOT NULL,
  `data_okonchanya` date NOT NULL,
  `nachisl_str_premya` decimal(10,2) NOT NULL,
  `oplach_premya` decimal(10,2) NOT NULL,
  `bank_posr` varchar(45) DEFAULT NULL,
  `primechanya` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `edinovr_oplata`
--

INSERT INTO `edinovr_oplata` (`edinovr_oplata`, `idagent`, `index_str`, `idstrahovatel`, `nomer_dogovora`, `data_nachala`, `data_okonchanya`, `nachisl_str_premya`, `oplach_premya`, `bank_posr`, `primechanya`) VALUES
(1, 1, 'КА', 3, 'ккк 3007015776', '2019-06-20', '2020-06-20', '3268.49', '3268.49', NULL, 'Skoda Fabia 2011 E028TK178'),
(2, 1, 'ОС', 5, 'ккк 3007015775', '2019-06-13', '2020-06-13', '3373.92', '3373.92', '', 'ВАЗ/LADA\r\n2171/Priora\r\n2013\r\nO773BT178'),
(3, 1, 'КА', 5, '7100 2484902', '2019-06-13', '2020-06-13', '2172.00', '2172.00', NULL, 'ВАЗ/LADA\r\n2171/Priora\r\n2013\r\nO773BT178');

-- --------------------------------------------------------

--
-- Структура таблицы `rassrochka`
--

CREATE TABLE `rassrochka` (
  `idrassrochka` int(11) NOT NULL,
  `idagent` int(11) NOT NULL DEFAULT 1,
  `index_str` varchar(15) NOT NULL,
  `idstrahovatel` int(11) NOT NULL,
  `nomer_dogovora` varchar(45) NOT NULL,
  `data_nachala` date NOT NULL,
  `data_okonchanya` date NOT NULL,
  `nachisl_str_premya` decimal(10,2) NOT NULL,
  `oplach_premya` decimal(10,2) NOT NULL,
  `kol_platezh` int(11) NOT NULL,
  `data_2pl` date NOT NULL,
  `data_3pl` date DEFAULT NULL,
  `data_4pl` date DEFAULT NULL,
  `summa_platezh` decimal(10,2) NOT NULL,
  `summa_2pl` decimal(10,2) NOT NULL,
  `summa_3pl` decimal(10,2) DEFAULT NULL,
  `summa_4pl` decimal(10,2) DEFAULT NULL,
  `bank_posr` varchar(45) DEFAULT NULL,
  `primechanya` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `rassrochka`
--

INSERT INTO `rassrochka` (`idrassrochka`, `idagent`, `index_str`, `idstrahovatel`, `nomer_dogovora`, `data_nachala`, `data_okonchanya`, `nachisl_str_premya`, `oplach_premya`, `kol_platezh`, `data_2pl`, `data_3pl`, `data_4pl`, `summa_platezh`, `summa_2pl`, `summa_3pl`, `summa_4pl`, `bank_posr`, `primechanya`) VALUES
(1, 1, 'ОС', 1, 'ккк 3007015775', '2020-06-05', '2021-06-05', '15000.00', '5000.00', 2, '2020-09-05', NULL, NULL, '10000.00', '10000.00', NULL, NULL, NULL, NULL),
(2, 1, 'КА', 5, 'ккк', '2020-12-12', '2021-12-12', '5000.00', '3000.00', 2, '2021-03-12', NULL, NULL, '2000.00', '2000.00', NULL, NULL, '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `strahovatel`
--

CREATE TABLE `strahovatel` (
  `idstrahovatel` int(11) NOT NULL,
  `FIO_Naimenov` varchar(150) NOT NULL,
  `data_rozden` date DEFAULT NULL,
  `address` varchar(250) NOT NULL,
  `rab_telefon` varchar(45) DEFAULT NULL,
  `mob_telefon_1` varchar(45) NOT NULL,
  `mob_telefon_2` varchar(45) DEFAULT NULL,
  `dom_telefon` varchar(45) DEFAULT NULL,
  `kategorya` varchar(15) NOT NULL,
  `primechanya` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `strahovka`
--

CREATE TABLE `strahovka` (
  `index_str` varchar(15) NOT NULL,
  `naimenov_str` varchar(150) NOT NULL,
  `karegorya_str` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `strahovka`
--

INSERT INTO `strahovka` (`index_str`, `naimenov_str`, `karegorya_str`) VALUES
('ГОЮР', 'Гражданская ответственность Юридических лиц', 'Юр. Лица'),
('ДМС', 'ДМС', 'Здоровье'),
('ДМСЮР', 'ДМС Юр. Лиц', 'Юр. Лица'),
('ДОМ', 'Дом', 'Имущество'),
('ЗК', 'Зеленая карта', 'Автомобиль'),
('ЗОК', 'Защита от клещей', 'Здоровье'),
('ИМЮР', 'Имущество Юридических лиц', 'Юр. Лица'),
('КА', 'КАСКО', 'Автомобиль'),
('КАЮР', 'КАСКО Юридических лиц', 'Автомобиль'),
('КВ', 'Квартира', 'Имущество'),
('МСДВ', 'Медицинская страховка для визы', 'Путешествия'),
('НСЮР', 'НС Юр.Лиц', 'Юр. Лица'),
('ОНС', 'Онкострахование', 'Здоровье'),
('ОС', 'ОСАГО', 'Автомобиль'),
('ОСОПО', 'Опасные Объекты', 'Юр. Лица'),
('ОСЮР', 'ОСАГО Юридических Лиц', 'Юр. Лица'),
('СП', 'Страхование Поездок', 'Путешествия'),
('ТМ', 'Телемедицина', 'Здоровье');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `agent`
--
ALTER TABLE `agent`
  ADD PRIMARY KEY (`idagent`);

--
-- Индексы таблицы `edinovr_oplata`
--
ALTER TABLE `edinovr_oplata`
  ADD PRIMARY KEY (`edinovr_oplata`),
  ADD KEY `idagent1` (`idagent`),
  ADD KEY `idstrahovatel1` (`idstrahovatel`),
  ADD KEY `index_str1` (`index_str`);

--
-- Индексы таблицы `rassrochka`
--
ALTER TABLE `rassrochka`
  ADD PRIMARY KEY (`idrassrochka`),
  ADD KEY `idagent` (`idagent`),
  ADD KEY `idstrahovatel` (`idstrahovatel`),
  ADD KEY `index_str` (`index_str`);

--
-- Индексы таблицы `strahovatel`
--
ALTER TABLE `strahovatel`
  ADD PRIMARY KEY (`idstrahovatel`);

--
-- Индексы таблицы `strahovka`
--
ALTER TABLE `strahovka`
  ADD PRIMARY KEY (`index_str`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `agent`
--
ALTER TABLE `agent`
  MODIFY `idagent` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `edinovr_oplata`
--
ALTER TABLE `edinovr_oplata`
  MODIFY `edinovr_oplata` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `rassrochka`
--
ALTER TABLE `rassrochka`
  MODIFY `idrassrochka` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `strahovatel`
--
ALTER TABLE `strahovatel`
  MODIFY `idstrahovatel` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `edinovr_oplata`
--
ALTER TABLE `edinovr_oplata`
  ADD CONSTRAINT `idagent1` FOREIGN KEY (`idagent`) REFERENCES `agent` (`idagent`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `idstrahovatel1` FOREIGN KEY (`idstrahovatel`) REFERENCES `strahovatel` (`idstrahovatel`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `index_str1` FOREIGN KEY (`index_str`) REFERENCES `strahovka` (`index_str`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `rassrochka`
--
ALTER TABLE `rassrochka`
  ADD CONSTRAINT `idagent` FOREIGN KEY (`idagent`) REFERENCES `agent` (`idagent`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `idstrahovatel` FOREIGN KEY (`idstrahovatel`) REFERENCES `strahovatel` (`idstrahovatel`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `index_str` FOREIGN KEY (`index_str`) REFERENCES `strahovka` (`index_str`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
